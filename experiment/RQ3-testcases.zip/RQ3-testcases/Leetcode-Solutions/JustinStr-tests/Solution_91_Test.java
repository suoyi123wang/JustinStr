import org.junit.Test;

public class Solution_91_Test {

  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_1_1() throws Exception{

      java.lang.String string1 = "o";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_2_2() throws Exception{

      java.lang.String string1 = "Ru";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_3_3() throws Exception{

      java.lang.String string1 = "2o";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_4_4() throws Exception{

      java.lang.String string1 = "u";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_5_5() throws Exception{

      java.lang.String string1 = "i";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_6_6() throws Exception{

      java.lang.String string1 = "e";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_7_7() throws Exception{

      java.lang.String string1 = "a";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_8_8() throws Exception{

      java.lang.String string1 = "6i";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_9_9() throws Exception{

      java.lang.String string1 = "%e";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_10_10() throws Exception{

      java.lang.String string1 = "9a";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_11_11() throws Exception{

      java.lang.String string1 = "U";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_12_12() throws Exception{

      java.lang.String string1 = "";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_13_13() throws Exception{

      java.lang.String string1 = "{\"key\":null}";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_14_14() throws Exception{

      java.lang.String string1 = "http://lcs.ios.ac.cn/";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_15_15() throws Exception{

      java.lang.String string1 = " ";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_16_16() throws Exception{

      java.lang.String string1 = " #";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_17_17() throws Exception{

      java.lang.String string1 = "tV\\\"4$'1O\\a!J";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_18_18() throws Exception{

      java.lang.String string1 = "\\n";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_19_19() throws Exception{

      java.lang.String string1 = ".\\a.txt";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



  @Test(timeout = 5000)
  public void test_findTheLongestSubstring_20_20() throws Exception{

      java.lang.String string1 = "{\"key\":2 }";
      Solution_91 solution_910 = null;
      solution_910.findTheLongestSubstring(string1);

  }



}