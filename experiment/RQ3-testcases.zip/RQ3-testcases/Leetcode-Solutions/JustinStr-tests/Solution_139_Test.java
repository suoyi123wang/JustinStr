import org.junit.Test;

public class Solution_139_Test {

  @Test(timeout = 5000)
  public void test_findReplaceString_1_1() throws Exception{

      java.lang.String string1 = "]";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_2_2() throws Exception{

      java.lang.String string1 = "";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_3_3() throws Exception{

      java.lang.String string1 = "<a> </a>";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_4_4() throws Exception{

      java.lang.String string1 = "Du4f\\Y@LSK~`VbO|-M.ugx6AZ\\A #";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_5_5() throws Exception{

      java.lang.String string1 = ")3p<W'wy~&cb0-Y3VjWmo>L+_lYxT,HHVO_DzRfZ.`^N>";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_6_6() throws Exception{

      java.lang.String string1 = "B%t)1T_/t]Q2,;E=`S>:6~-j;7\\\"+y";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_7_7() throws Exception{

      java.lang.String string1 = "[0,1]";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_8_8() throws Exception{

      java.lang.String string1 = "a ";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_9_9() throws Exception{

      java.lang.String string1 = "a ";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_10_10() throws Exception{

      java.lang.String string1 = "http://lcs.ios.ac.cn/";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_11_11() throws Exception{

      java.lang.String string1 = "{\"key\":null}";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_12_12() throws Exception{

      java.lang.String string1 = " #";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_13_13() throws Exception{

      java.lang.String string1 = "{\"key\":2 }";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_14_14() throws Exception{

      java.lang.String string1 = "\\n";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_15_15() throws Exception{

      java.lang.String string1 = "[0,1]";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_16_16() throws Exception{

      java.lang.String string1 = "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_17_17() throws Exception{

      java.lang.String string1 = " #";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_18_18() throws Exception{

      java.lang.String string1 = "http://lcs.ios.ac.cn/";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_19_19() throws Exception{

      java.lang.String string1 = " #";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



  @Test(timeout = 5000)
  public void test_findReplaceString_20_20() throws Exception{

      java.lang.String string1 = "<a> </a>";
      int[] intArray2 = {};
      java.lang.String[] stringArray3 = {};
      java.lang.String[] stringArray4 = {};
      Solution_139 solution_1390 = new Solution_139();
      solution_1390.findReplaceString(string1, intArray2, stringArray3, stringArray4);

  }



}