import org.junit.Test;

public class Solution_271_Test {

  @Test(timeout = 5000)
  public void test_isNumber_1_1() throws Exception{

      java.lang.String string1 = "v";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_2_2() throws Exception{

      java.lang.String string1 = "";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_3_3() throws Exception{

      java.lang.String string1 = "`p[XJ%\\\"y2gpzL[a]{,Z6l8 ,[^n+V/c>cYv";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_4_4() throws Exception{

      java.lang.String string1 = "http://lcs.ios.ac.cn/";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_5_5() throws Exception{

      java.lang.String string1 = "\\n";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_6_6() throws Exception{

      java.lang.String string1 = "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_7_7() throws Exception{

      java.lang.String string1 = "\\n";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_8_8() throws Exception{

      java.lang.String string1 = "<a> </a>";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_9_9() throws Exception{

      java.lang.String string1 = "{\"key\":2 }";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_10_10() throws Exception{

      java.lang.String string1 = "a ";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_11_11() throws Exception{

      java.lang.String string1 = "[0,1]";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_12_12() throws Exception{

      java.lang.String string1 = "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_13_13() throws Exception{

      java.lang.String string1 = ".\\a.txt";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_14_14() throws Exception{

      java.lang.String string1 = "\\n";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_15_15() throws Exception{

      java.lang.String string1 = "";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_16_16() throws Exception{

      java.lang.String string1 = "a ";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_17_17() throws Exception{

      java.lang.String string1 = "http://lcs.ios.ac.cn/";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_18_18() throws Exception{

      java.lang.String string1 = "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_19_19() throws Exception{

      java.lang.String string1 = "{\"key\":null}";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



  @Test(timeout = 5000)
  public void test_isNumber_20_20() throws Exception{

      java.lang.String string1 = "http://lcs.ios.ac.cn/";
      Solution_271 solution_2710 = new Solution_271();
      solution_2710.isNumber(string1);

  }



}