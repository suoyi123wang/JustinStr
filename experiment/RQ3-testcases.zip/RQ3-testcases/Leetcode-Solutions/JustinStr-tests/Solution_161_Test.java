import org.junit.Test;

public class Solution_161_Test {

  @Test(timeout = 5000)
  public void test_evaluate_inner_1_1() throws Exception{

      java.lang.String string1 = "1(";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_2_2() throws Exception{

      java.lang.String string1 = "(";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_3_3() throws Exception{

      java.lang.String string1 = "Jadd";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_4_4() throws Exception{

      java.lang.String string1 = "nmult";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_5_5() throws Exception{

      java.lang.String string1 = "pm";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_6_6() throws Exception{

      java.lang.String string1 = "`,m";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_7_7() throws Exception{

      java.lang.String string1 = "m";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_8_8() throws Exception{

      java.lang.String string1 = "M-";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_9_9() throws Exception{

      java.lang.String string1 = "!";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_10_10() throws Exception{

      java.lang.String string1 = "";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_11_11() throws Exception{

      java.lang.String string1 = "-";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_12_12() throws Exception{

      java.lang.String string1 = ".\\a.txt";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_13_13() throws Exception{

      java.lang.String string1 = "a ";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_14_14() throws Exception{

      java.lang.String string1 = "~8E";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_15_15() throws Exception{

      java.lang.String string1 = ".\\a.txt";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_16_16() throws Exception{

      java.lang.String string1 = "\\n";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_17_17() throws Exception{

      java.lang.String string1 = "^[1]([3-9])[0-9]{9}$";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_18_18() throws Exception{

      java.lang.String string1 = "a ";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_19_19() throws Exception{

      java.lang.String string1 = "http://lcs.ios.ac.cn/";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



  @Test(timeout = 5000)
  public void test_evaluate_inner_20_20() throws Exception{

      java.lang.String string1 = "[0,1]";
      Solution_161 solution_1610 = new Solution_161();
      solution_1610.evaluate_inner(string1);

  }



}