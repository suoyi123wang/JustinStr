import org.junit.Test;

public class Solution_206_Test {

  @Test(timeout = 5000)
  public void test_frequencySort_1_1() throws Exception{

      java.lang.String string1 = "r";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_2_2() throws Exception{

      java.lang.String string1 = "";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_3_3() throws Exception{

      java.lang.String string1 = "{\"key\":2 }";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_4_4() throws Exception{

      java.lang.String string1 = " ";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_5_5() throws Exception{

      java.lang.String string1 = " ";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_6_6() throws Exception{

      java.lang.String string1 = "<a>Hello World</a>";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_7_7() throws Exception{

      java.lang.String string1 = "<a>Hello World</a>";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_8_8() throws Exception{

      java.lang.String string1 = "[0,1]";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_9_9() throws Exception{

      java.lang.String string1 = "l}/sdlAOD[<{I_m)(K93$IgNW)";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_10_10() throws Exception{

      java.lang.String string1 = "a ";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_11_11() throws Exception{

      java.lang.String string1 = " ";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_12_12() throws Exception{

      java.lang.String string1 = "[0,1]";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_13_13() throws Exception{

      java.lang.String string1 = "";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_14_14() throws Exception{

      java.lang.String string1 = "http://lcs.ios.ac.cn/";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_15_15() throws Exception{

      java.lang.String string1 = "a ";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_16_16() throws Exception{

      java.lang.String string1 = "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_17_17() throws Exception{

      java.lang.String string1 = "a ";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_18_18() throws Exception{

      java.lang.String string1 = "a ";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_19_19() throws Exception{

      java.lang.String string1 = "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



  @Test(timeout = 5000)
  public void test_frequencySort_20_20() throws Exception{

      java.lang.String string1 = "[0,1]";
      Solution_206 solution_2060 = new Solution_206();
      solution_2060.frequencySort(string1);

  }



}