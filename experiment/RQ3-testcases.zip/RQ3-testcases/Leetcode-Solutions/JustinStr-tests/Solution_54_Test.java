import org.junit.Test;

public class Solution_54_Test {

  @Test(timeout = 5000)
  public void test_maximumTime_1_1() throws Exception{

      java.lang.String string1 = "Ta4";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_2_2() throws Exception{

      java.lang.String string1 = "9";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_3_3() throws Exception{

      java.lang.String string1 = "x;v|";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_4_4() throws Exception{

      java.lang.String string1 = "\t";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_5_5() throws Exception{

      java.lang.String string1 = "4";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_6_6() throws Exception{

      java.lang.String string1 = "?";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_7_7() throws Exception{

      java.lang.String string1 = "KI|?";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_8_8() throws Exception{

      java.lang.String string1 = "iUO";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_9_9() throws Exception{

      java.lang.String string1 = "2";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_10_10() throws Exception{

      java.lang.String string1 = "V2";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_11_11() throws Exception{

      java.lang.String string1 = "?";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_12_12() throws Exception{

      java.lang.String string1 = "[=dlz";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_13_13() throws Exception{

      java.lang.String string1 = "29";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_14_14() throws Exception{

      java.lang.String string1 = "IdEM?";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_15_15() throws Exception{

      java.lang.String string1 = "it9";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_16_16() throws Exception{

      java.lang.String string1 = "O?";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_17_17() throws Exception{

      java.lang.String string1 = "";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_18_18() throws Exception{

      java.lang.String string1 = "l4";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_19_19() throws Exception{

      java.lang.String string1 = "^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



  @Test(timeout = 5000)
  public void test_maximumTime_20_20() throws Exception{

      java.lang.String string1 = "{\"key\":2 }";
      Solution_54 solution_540 = new Solution_54();
      solution_540.maximumTime(string1);

  }



}